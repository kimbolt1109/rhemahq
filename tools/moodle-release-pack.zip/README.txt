Assessment Release Pack

Extract the entire ZIP, then open tools/moodle/index.html in a current browser.
Keep the folders together. Load a sample or choose your own files to begin.
The tool processes files offline. Internal, non-commercial evaluation is free.
A valid standard Polar license key grants one non-transferable commercial seat.
Agency and Campus use follow the named operators and scope in a separately accepted written agreement.
See LICENSE.txt for the software license terms.
Support: support@rhemahq.com

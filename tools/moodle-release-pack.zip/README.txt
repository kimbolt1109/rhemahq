Assessment Release Pack

Extract the entire ZIP, then open tools/moodle/index.html in a current browser.
Keep the folders together. Load a sample or choose your own files to begin.
The tool processes files offline. See LICENSE.txt for evaluation and commercial terms.
Support: support@rhemahq.com

# OJS Galley Studio
DOCX to PDF / HTML / JATS Publishing 1.2 galleys for OJS production, plus a native OJS galley-registration companion.
## make-galleys.py
python make-galleys.py article.docx --meta jats.json --out ./galleys --pandoc <pandoc> --dtd <JATS-journalpublishing1.dtd> [--template article-template.html] [--edge <chromium>]
Requires pandoc 3.x, lxml; pypdf + a Chromium binary only for the PDF galley. Validates against the official NLM JATS Publishing 1.2 DTD and writes artifact-hashes.json (SHA-256 per galley).
## register-galleys.php
Native OJS 3.5 CLI companion (verified on OJS 3.5.0.4). Place beside your OJS install (expects ./ojs-3.5.0-4) and run with PHP; it creates a disabled test journal, a production-stage submission and registers the galley files. Defaults reproduce the verified fixture run; adapt the editor username and paths to your install and re-run there before production use.
## Verification
Fixture run 2026-11-22: DOCX to PDF/HTML/JATS PASS, official JATS Publishing 1.2 DTD PASS, four artifacts checksummed. OJS registration verified 2026-11-20 on native OJS 3.5.0.4.
## License and disclosure
GPL-3.0 (LICENSE.txt). AI-assisted authorship is disclosed per PKP policy; a qualified contributor should review before any external OJS gallery submission.

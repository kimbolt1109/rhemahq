<?php
declare(strict_types=1);

use APP\core\Application;
use APP\facades\Repo;
use PKP\db\DAORegistry;
use PKP\submissionFile\SubmissionFile;

$root = __DIR__;
$app = $root . '/ojs-3.5.0-4';
chdir($app);
require $app . '/tools/bootstrap.php';
$tool = new \PKP\cliTool\CommandLineTool([__FILE__, '-u', 'fixtureadmin']);
$request = Application::get()->getRequest();
$user = $request->getUser();
if (!$user || $user->getUsername() !== 'fixtureadmin') {
    throw new RuntimeException('Native CLI did not load the test editor.');
}
function check_contract(bool $ok, string $why): void {
    if (!$ok) { throw new RuntimeException($why); }
}
$journal = Application::getContextDAO()->newDataObject();
$journal->setData('name', ['en' => 'Local Galley Test']);
$journal->setData('acronym', ['en' => 'LGT']);
$journal->setData('urlPath', 'galley-test-' . bin2hex(random_bytes(3)));
$journal->setData('primaryLocale', 'en');
$journal->setData('supportedLocales', ['en']);
$journal->setData('enabled', false);
$context = app()->get('context')->add($journal, $request);
$contextId = $context->getId();

$section = Repo::section()->newDataObject([
    'contextId' => $contextId, 'title' => ['en' => 'Fixture Articles'],
    'abbrev' => ['en' => 'FIXT'], 'restricted' => false, 'seq' => 1,
]);
$sectionId = Repo::section()->add($section);
$publication = Repo::publication()->newDataObject([
    'title' => ['en' => 'Local journal galley check'], 'sectionId' => $sectionId,
    'locale' => 'en',
]);
$submission = Repo::submission()->newDataObject([
    'contextId' => $contextId, 'stageId' => WORKFLOW_STAGE_ID_PRODUCTION,
    'locale' => 'en',
]);
$submissionId = Repo::submission()->add($submission, $publication, $context);
$submission = Repo::submission()->get($submissionId);
$publication = $submission->getCurrentPublication();
check_contract($publication->getData('title','en') === 'Local journal galley check',
    'OJS lost the draft publication title.');

$genre = DAORegistry::getDAO('GenreDAO')->getEnabledByContextId($contextId)->next();
check_contract($genre !== null, 'No enabled genre in the native test journal.');
$genreId = $genre->getId();
$files = app()->get('file');
$base = Repo::submissionFile()->getSubmissionDir($contextId,$submissionId);
$private = \PKP\config\Config::getVar('files','files_dir');
function receive_file(
    string $path, string $base, string $private, int $submissionId,
    int $genreId, int $userId, int $stage, array $mimes, array $related = []
): int {
    $fileService = app()->get('file');
    $pathId = $fileService->add($path, $base . '/fixture-' . basename($path));
    $params = [
        'fileId' => $pathId, 'submissionId' => $submissionId,
        'uploaderUserId' => $userId, 'name' => ['en' => basename($path)],
        'genreId' => $genreId, 'fileStage' => $stage,
    ] + $related;
    $errors = Repo::submissionFile()->validate(null, $params, ['en'], 'en');
    check_contract(!$errors, 'OJS rejected fixture file ' . basename($path) . ' ' . json_encode($errors));
    $id = Repo::submissionFile()->add(Repo::submissionFile()->newDataObject($params));
    $stored = Repo::submissionFile()->get($id);
    check_contract($stored !== null && (int)$stored->getData('fileStage') === $stage,
        'OJS lost the submission file or its workflow stage.');
    $entry = $fileService->get($stored->getData('fileId'));
    check_contract(in_array($entry->mimetype,$mimes,true),'OJS stored an unexpected MIME type: ' . $entry->mimetype);
    $dest = $private . '/' . $entry->path;
    check_contract(is_file($dest) && hash_file('sha256',$dest) === hash_file('sha256',$path),
        'OJS private storage altered the file bytes.');
    if ($related) {
        check_contract((int)$stored->getData('assocId') === $related['assocId']
            && (int)$stored->getData('assocType') === $related['assocType'],
            'OJS changed the dependent-file association.');
    }
    return $id;
}
$input = $root . '/journal-fixture';
$galleys = [
    'PDF' => ['article.pdf', ['application/pdf']],
    'HTML' => ['article.html', ['text/html']],
    'JATS XML' => ['article.xml', ['application/xml','text/xml']],
];
$xmlId = null;
foreach ($galleys as $label => [$name, $types]) {
    $file = receive_file($input.'/'.$name,$base,$private,$submissionId,$genreId,$user->getId(),
        SubmissionFile::SUBMISSION_FILE_PROOF,$types);
    $params = [
        'publicationId'=>$publication->getId(), 'label'=>$label, 'locale'=>'en',
        'submissionFileId'=>$file,
    ];
    $errors = Repo::galley()->validate(null,$params,['en'],'en');
    check_contract(!$errors,'OJS rejected galley ' . $label . ' ' . json_encode($errors));
    $id = Repo::galley()->add(Repo::galley()->newDataObject($params));
    $saved = Repo::galley()->get($id,$publication->getId());
    check_contract($saved !== null && $saved->getData('label') === $label,
        'OJS did not register a galley against the draft publication.');
    check_contract((int)$saved->getData('submissionFileId') === $file,'OJS lost galley file association.');
    if ($label === 'JATS XML') { $xmlId = $file; }
}
$doc = new DOMDocument();
check_contract($doc->load($input.'/article.xml',LIBXML_NONET),'The JATS source could not be parsed.');
$xp = new DOMXPath($doc);
$xp->registerNamespace('xlink','http://www.w3.org/1999/xlink');
$path = $xp->evaluate('string((//graphic)[1]/@xlink:href)');
$abs = realpath($input.'/'.$path);
check_contract($xmlId !== null && $abs !== false && str_starts_with(str_replace('\\','/',$abs),str_replace('\\','/',$input).'/'),
    'JATS fixture lacks the expected local relative graphic.');
receive_file($abs,$base,$private,$submissionId,$genreId,$user->getId(),
    SubmissionFile::SUBMISSION_FILE_DEPENDENT,['image/png'],
    ['assocType'=>Application::ASSOC_TYPE_SUBMISSION_FILE,'assocId'=>$xmlId]);
echo "OJS native production repositories: 3 galleys, 1 attached image, expected MIME types and 4 original SHA-256 byte checks PASS.\n";

"""OJS Galley Studio - DOCX to PDF / HTML / JATS Publishing 1.2 galleys.

Generalized from the verified local pipeline (fixture run 2026-11-20, OJS 3.5.0.4
handoff). Converts a Word manuscript plus a metadata JSON into three galleys and
validates the JATS against the official NLM Publishing 1.2 DTD.

Usage:
  python make-galleys.py article.docx --meta jats.json --out ./galleys \
      --pandoc /path/to/pandoc --dtd /path/to/JATS-journalpublishing1.dtd \
      [--html-meta html.json] [--template template.html] [--edge /path/to/msedge]

Requires: pandoc >= 3.x, lxml, pypdf (only when --edge is given), and Edge or
another Chromium browser for the two-column PDF. Nothing is uploaded.
"""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

from lxml import etree


def run(args, cwd):
    cp = subprocess.run(args, cwd=cwd, check=False, capture_output=True, text=True, encoding="utf-8")
    if cp.returncode:
        raise RuntimeError(str(args[0]) + ": " + cp.stderr[:1500])
    return cp.stdout


def main():
    ap = argparse.ArgumentParser(description="DOCX to PDF/HTML/JATS galleys for OJS production.")
    ap.add_argument("docx", type=Path)
    ap.add_argument("--meta", type=Path, required=True, help="JATS metadata JSON")
    ap.add_argument("--html-meta", type=Path, help="HTML metadata JSON (defaults to --meta with author flattened)")
    ap.add_argument("--template", type=Path, help="pandoc HTML template (two-column print CSS)")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--pandoc", default="pandoc")
    ap.add_argument("--dtd", type=Path, required=True)
    ap.add_argument("--edge", type=Path, help="Chromium binary; omit to skip the PDF galley")
    args = ap.parse_args()

    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    meta = json.loads(args.meta.read_text(encoding="utf-8"))
    html_meta = json.loads(args.html_meta.read_text(encoding="utf-8")) if args.html_meta else dict(meta, author=[
        (a.get("given-names", "") + " " + a.get("surname", "")).strip() if isinstance(a, dict) else a
        for a in meta.get("author", [])
    ])
    (out / "jats.json").write_text(json.dumps(meta), encoding="utf-8")
    (out / "html.json").write_text(json.dumps(html_meta), encoding="utf-8")

    stem = args.docx.stem
    html_args = [args.pandoc, str(args.docx), "-t", "html5", "--standalone", "--embed-resources",
                 "--metadata-file=" + str(out / "html.json"), "--wrap=none"]
    if args.template:
        html_args += ["--template=" + str(args.template)]
    html_args += ["-o", str(out / (stem + ".html"))]
    run(html_args, out)
    run([args.pandoc, str(args.docx), "-t", "jats_publishing", "--standalone", "--wrap=none",
         "--extract-media=assets", "--metadata-file=" + str(out / "jats.json"),
         "-o", str(out / (stem + ".xml"))], out)

    parser = etree.XMLParser(resolve_entities=False, no_network=True)
    xml = etree.parse(str(out / (stem + ".xml")), parser)
    ab = xml.find(".//abstract")
    if ab is not None and len(ab) == 0 and ab.text and ab.text.strip():
        original = ab.text.strip()
        if original != meta.get("abstract", original):
            raise RuntimeError("JATS abstract does not match supplied metadata.")
        ab.text = None
        etree.SubElement(ab, "p").text = original
    article = xml.find(".//article-meta")
    if article is None:
        raise RuntimeError("JATS output has no article-meta.")
    dates = article.findall("pub-date")
    if not dates:
        raise RuntimeError("JATS output has no pub-date.")
    cursor = article.index(dates[-1]) + 1
    for tag in ("volume", "issue"):
        if tag not in meta:
            continue
        existing = article.find(tag)
        if existing is None:
            node = etree.Element(tag)
            node.text = str(meta[tag])
            article.insert(cursor, node)
            cursor += 1
        elif existing.text != str(meta[tag]):
            raise RuntimeError("JATS " + tag + " does not match supplied metadata.")
    xml.write(str(out / (stem + ".xml")), encoding="UTF-8", xml_declaration=True)

    validator = etree.DTD(str(args.dtd))
    if not validator.validate(xml):
        raise RuntimeError("JATS DTD validation failed: " + str(validator.error_log)[-2300:])

    if xml.findtext(".//article-title") != meta.get("title"):
        raise RuntimeError("JATS article-title does not match supplied metadata.")
    doi = meta.get("article", {}).get("doi")
    if doi and xml.findtext(".//article-id[@pub-id-type='doi']") != doi:
        raise RuntimeError("JATS DOI does not match supplied metadata.")

    graphics = xml.xpath(".//graphic")
    for g in graphics:
        href = g.get("{http://www.w3.org/1999/xlink}href")
        f = (out / href).resolve()
        if not f.is_relative_to(out.resolve()) or not f.is_file():
            raise RuntimeError("Extracted media missing or escapes output dir: " + str(href))

    html_content = (out / (stem + ".html")).read_text(encoding="utf-8")
    if meta.get("title") and meta["title"] not in html_content:
        raise RuntimeError("HTML galley lost the article title.")

    targets = [out / (stem + ".html"), out / (stem + ".xml")]
    if args.edge:
        run([str(args.edge), "--headless", "--disable-gpu", "--disable-background-networking",
             "--disable-extensions", "--no-first-run", "--no-pdf-header-footer",
             "--user-data-dir=" + str(out / "edge-profile"),
             "--print-to-pdf=" + str(out / (stem + ".pdf")), (out / (stem + ".html")).as_uri()], out)
        from pypdf import PdfReader
        pdf = PdfReader(out / (stem + ".pdf"))
        text = " ".join(pdf.pages[0].extract_text().split())
        if meta.get("title") and meta["title"] not in text:
            raise RuntimeError("PDF galley lost the article title.")
        targets.append(out / (stem + ".pdf"))
    for g in graphics:
        targets.append((out / g.get("{http://www.w3.org/1999/xlink}href")).resolve())
    checks = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in targets}
    (out / "artifact-hashes.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    print("Galleys written to", out)
    print("Official NLM JATS Publishing 1.2 DTD: PASS")
    print("Checksummed:", ", ".join(sorted(checks)))


if __name__ == "__main__":
    main()
